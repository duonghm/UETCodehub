/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.edu.vnu.uet.fit.models;

import org.hibernate.Session;
import org.hibernate.Transaction;
import vn.edu.vnu.uet.fit.entities.Submissions;
import vn.edu.vnu.uet.fit.utils.HibernateUtil;

/**
 *
 * @author hmduong
 */
public class SubmissionModel {
    
    public void saveSubmission(int submitId, String result){
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction trans = session.beginTransaction();
        Submissions submission = (Submissions)session.get(Submissions.class, submitId);
        submission.setResult(result);
        session.update(submission);
        trans.commit();
        session.close();
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vn.edu.vnu.uet.fit.service;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.Oneway;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import service.JudgeService_Service;
import vn.edu.vnu.uet.fit.models.SubmissionModel;

/**
 *
 * @author hmduong
 */
@WebService(serviceName = "SubmitService")
public class SubmitService {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "submit")
    @Oneway
    public void submit(@WebParam(name="submitId") int submitId, @WebParam(name = "problemId") int problemId, @WebParam(name = "sourceCode") String sourceCode, @WebParam(name = "language") String language, @WebParam(name = "limitTime") float limitTime, @WebParam(name = "limitMemory") int limitMemory, @WebParam(name = "isUseCustomCheck") boolean isUseCustomCheck) {        
        JudgeService_Service service = new JudgeService_Service();
        String result = service.getJudgeServicePort().judge(problemId, sourceCode, language, limitTime, limitMemory, isUseCustomCheck);
        System.out.println(result);
        SubmissionModel model = new SubmissionModel();
        model.saveSubmission(submitId, result);
    }

    /**
     * Web service operation
     * @param id
     */
    @WebMethod(operationName = "demoOneWay")
    @Oneway
    public void demoOneWay(@WebParam(name = "id") int id) {
        try {
            Thread.sleep(10000);
        } catch (InterruptedException ex) {
            Logger.getLogger(SubmitService.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("id: " + id);        
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "demoCallWS")
    @Oneway
    public void demoCallWS(@WebParam(name = "problemId") int problemId, @WebParam(name = "sourceCode") String sourceCode, @WebParam(name = "language") String language) {
        JudgeService_Service service = new JudgeService_Service();
        String r = service.getJudgeServicePort().judge(problemId, sourceCode, language, 1, 0, false);
        System.out.println(r);
        //return r;
    }
    
    
}

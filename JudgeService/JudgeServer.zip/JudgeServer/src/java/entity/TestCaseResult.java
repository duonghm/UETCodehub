/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author duonghm[at]vnu.edu.vn
 */
public class TestCaseResult {
    String testName;
    String result;
    String message;

    public TestCaseResult() {
    }
    
    public TestCaseResult(String testName, String result, String message) {
        this.testName = testName;
        this.result = result;
        this.message = message;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    String toJSON(){
        String json="{";
        json += JSONUtil.createJsonPair("testName", testName);
        json += ",";
        json += JSONUtil.createJsonPair("result", result);
        json += ",";
        json += JSONUtil.createJsonPair("message", message);
        json += "}";
        return json;
    }
}

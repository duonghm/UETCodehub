/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author duonghm[at]vnu.edu.vn
 */
public class JSONUtil {
    public static String addDoubleQuote(String str){
        return "\""+str+"\"";
    }
    
    public static String createJsonPair(String field, String value){
        return addDoubleQuote(field)+":"+addDoubleQuote(value);
    }
}

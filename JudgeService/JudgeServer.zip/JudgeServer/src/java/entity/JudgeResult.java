/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.util.ArrayList;

/**
 *
 * @author duonghm[at]vnu.edu.vn
 */
public class JudgeResult {
    private String resultCode;
    private int score;
    private String errorMessage;
    private ArrayList<TestCaseResult> lstResult = new ArrayList<>();

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public ArrayList<TestCaseResult> getLstResult() {
        return lstResult;
    }

    public void setLstResult(ArrayList<TestCaseResult> lstResult) {
        this.lstResult = lstResult;
    }
    
    public String toJSON(){
        String json = "";
        json += "{";
        json += JSONUtil.createJsonPair("resultCode", resultCode);
        json += ",";
        boolean isAccept = true;
        switch(resultCode){
            case "AC":
                isAccept = true;
                break;
            case "CE":
                isAccept = false;
                errorMessage = "Compile error";
                break;
            case "VS":
                isAccept = false;
                errorMessage = "Violation source";
                break;
            case "NA":
                isAccept = false;
                errorMessage = "Not Accept";
                break;
        }
        
        if(isAccept){
            json += JSONUtil.createJsonPair("score", String.valueOf(score));
            json += ",";
            json += JSONUtil.addDoubleQuote("testDetail")+":";
            json += "[";
            if(lstResult.size()>0){
                for(int i=0; i<lstResult.size()-1; i++){
                    json += lstResult.get(i).toJSON() + ",";
                }
                json += lstResult.get(lstResult.size()-1).toJSON();
            }
            json += "]";
        }else{
            json += JSONUtil.createJsonPair("message", errorMessage);
        }
        
        json += "}";
        return json;
    }
    
    public void addData(String data){
        if(data.startsWith("-")){
            data = data.substring(1);
            String[] splitData = data.split(":");
            switch(splitData[0]){
                case "resultCode":
                    setResultCode(splitData[1]);
                    break;
                case "score":
                    setScore(Integer.valueOf(splitData[1]));
                    break;                    
            }
        }else if(data.startsWith("+")){
            data = data.substring(1);
            String[] splitData = data.split(":");
            TestCaseResult tcr = new TestCaseResult(splitData[0], splitData[1], splitData[2]);
            lstResult.add(tcr);
        }else{
            errorMessage += data;
        }
    }
    
    public void addError(String msg){
        errorMessage += msg;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import entity.JudgeResult;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.servlet.ServletContext;
import javax.ws.rs.core.Context;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import util.FileManipulator;

/**
 *
 * @author duonghm[at]vnu.edu.vn
 */
@WebService(serviceName = "JudgeService")
public class JudgeService {

    @Resource
    private WebServiceContext context;
    
    ServletContext servletContext;
    
    ServletContext getServletContext(){
        if(servletContext==null){
            servletContext = (ServletContext) context.getMessageContext().get(MessageContext.SERVLET_CONTEXT);
        }
        return servletContext;
    }
    
    String getJudgeEnviromentFolder(){
        return getServletContext().getRealPath(JUDGE_ENVIROMENT);
    }
    
    String getTestCaseLocation(){
        return getServletContext().getRealPath(TESTCASE_LOCATION);
    }
    
    final static String JUDGE_ENVIROMENT = "JudgeEnv";
    final static String JUDGE_FILE = "judge.sh";
    final static String TESTCASE_LOCATION = "JudgeEnv/Testcase";
    final static String DEFAULT_EXECUTION_FILENAME = "test";        
    final static String DEFAULT_INPUT_DIR = "input";
    final static String DEFAULT_ANSWER_DIR = "answer";
    final static String DEFAULT_OUTPUT_DIR = "output";
    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "judge")
    public String judge(@WebParam(name = "problemId") int problemId, @WebParam(name = "sourceCode") String sourceCode, @WebParam(name = "language") String language, @WebParam(name = "limitTime") float limitTime, @WebParam(name = "limitMemory") int limitMemory, @WebParam(name = "isUseCustomCheck") boolean isUseCustomCheck) {
        String result = ""; 
        try {
            String fileExtention = "";
            switch(language){
                case "C":
                    fileExtention = ".c";
                    break;
                case "C++":
                    fileExtention = ".cpp";                    
                    break;
            }
            
            // Create source code file
            FileManipulator fm = new FileManipulator();
            String sourceCodeFilePath = getJudgeEnviromentFolder() + "/" + DEFAULT_EXECUTION_FILENAME + fileExtention;
            System.out.println("Source code: " + sourceCodeFilePath);
            fm.createFile(sourceCode, sourceCodeFilePath);
            
            //Run judge
            String judgeFilePath = getJudgeEnviromentFolder() + "/" + JUDGE_FILE;
            ProcessBuilder pb = new ProcessBuilder("sudo", "chmod", "777", judgeFilePath);
            pb.start();
            
            String inputDir = getTestCaseLocation() + "/" + problemId + "/" + DEFAULT_INPUT_DIR;
            String answerDir = getTestCaseLocation() + "/" + problemId + "/" + DEFAULT_ANSWER_DIR;
            String outputDir = getJudgeEnviromentFolder() + "/" + DEFAULT_OUTPUT_DIR;            
            
            pb = new ProcessBuilder("sudo", judgeFilePath, sourceCodeFilePath, String.valueOf(limitTime), String.valueOf(limitMemory), inputDir, outputDir, answerDir);
            result += pb.command() + "<br>";
            Process p = pb.start();
            p.waitFor();
            
            /*
            //Read console output
            System.out.println("=== Run Result: ===");
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null)
            {
                result += line + "<br>";
                System.out.println(line);
            }
            result += "=== Error: ===<br>" ;
            reader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            while ((line = reader.readLine()) != null)
            {
                result += line + "<br>";
                System.out.println(line);
            }
            */
            
            JudgeResult jr = new JudgeResult();
            
            System.out.println("===OUTPUT===");
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = null;            
            while ((line = reader.readLine()) != null)
            {   
                jr.addData(line);
                System.out.println(line);                
            }
            
            System.out.println("===ERROR===");
            reader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            while ((line = reader.readLine()) != null)
            {
                jr.addError(line);
                System.out.println(line);
            }
            
            result = jr.toJSON();
        } catch (IOException ex) {
            Logger.getLogger(JudgeService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(JudgeService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "TestInvokeFile")
    public String TestInvokeFile() {
        try {
            ServletContext servletContext =
                    (ServletContext) context.getMessageContext().get(MessageContext.SERVLET_CONTEXT);
            String path = servletContext.getRealPath("JudgeEnv");
            //String shellFile = path + "/simple.sh";
            String shellFile = servletContext.getRealPath("JudgeEnv/simple.sh");
            System.out.println("Path: " + path);
            System.out.println("Shell file: " + shellFile);
            ProcessBuilder pb = new ProcessBuilder("sudo", "chmod", "777", shellFile);
            pb.start();
            
            pb = new ProcessBuilder("sudo", shellFile);
            pb.directory(new File(path));
            Process p = pb.start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null)
            {
                System.out.println(line);
            }            
            System.out.println("Call done");            
        } catch (IOException ex) {
            Logger.getLogger(JudgeService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
}

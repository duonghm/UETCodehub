<?php
	$client = new SoapClient("http://localhost:8080/JudgeServer/JudgeService?WSDL", array('cache_wsdl' => WSDL_CACHE_NONE));
		
	$judgeRequest = new stdClass();
	$judgeRequest->problemId = 2;
	$judgeRequest->sourceCode = 
		"#include<iostream>

using namespace std;

int main(){
	int i;
	//while(1)
	cin >> i;
	cout << i;
	return 0;
}";
	$judgeRequest->language = "C++";
	$judgeRequest->limitTime = 1;
	$judgeRequest->limitMemory = 1000;
	$judgeRequest->isUseCustomCheck = false;
	
	$result = $client->judge($judgeRequest);
	echo $result->return;
?>

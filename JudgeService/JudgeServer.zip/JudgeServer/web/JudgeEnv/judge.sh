#usage: ./judge.sh test.cpp 1 2000000 input output answer
SOURCE=$1
DEFAULT_EXEC=test
TIME_LIMIT=$2
MEMORY_LIMIT=$3
INPUT_DIR=$4
OUTPUT_DIR=$5
ANSWER_DIR=$6

Compile(){
	g++ $SOURCE -o $DEFAULT_EXEC
	return $?
}

MatchAnswerWithOutput(){
	diff -w $1 $2
	return $?
}

JudgeOneTestCase(){
	input=$1
	output=$2
	answer=$3
	timeout $TIME_LIMIT ./$DEFAULT_EXEC < $input > $output
	code=$?
	if [ $code -eq 124 ]
	then 		
		#Code 124: Timeout
		return 2
	elif [ $code -eq 0 ]
	then
		#Code 0: Output Success
		MatchAnswerWithOutput $output $answer
		if [ $? -eq 0 ]
		then
			#Match code 0: Pass Test			
			return 1
		else
			#Match code 1: Fail Test			
			return 0
		fi
	else
		#Other code: Unhandled error		
		return 3
	fi
}

#===Main program===
#Limit using resource
ulimit -f 2000000 #limit file size (blocks)
#ulimit -r 2000000 #limit memory size (Kbytes)
ulimit -v 2000000 #limit virtual memory
#Compile source code
Compile
c_code=$?;
if [ $c_code -eq 0 ]
then
	#Compile success
	#echo "Compile Success"
        echo "-resultCode:AC"
	score=0
	numOfTest=0
	for inputfile in $INPUT_DIR/*.txt
	do
		numOfTest=$((numOfTest+1))
		filename=$(basename $inputfile)
		name="${filename%.*}"
		JudgeOneTestCase $INPUT_DIR/$filename $OUTPUT_DIR/$filename $ANSWER_DIR/$filename
		j_code=$?
		if [ $j_code -eq 2 ]
		then
			#echo "Time out"
			echo "+"$name":TO:Time out"			
		elif [ $j_code -eq 3 ]
		then			
			#echo "Unknown error"
			echo "+"$name":E:Unknown Error"
		elif [ $j_code -eq 0 ]
		then
			#echo "Fail test"
			echo "+"$name":F:Fail test"
		elif [ $j_code -eq 1 ]
		then
			score=$((score+1))
			#echo "Pass test"
			echo "+"$name":P:Pass test"
		fi		
	done
	ratio=$((score/numOfTest*100))
	#echo $score / $numOfTest
	echo "-score:"$ratio
	exit 0
else
	#Compile error
	echo "-resultCode:CE"	
	exit 1
fi
